# SimpleCalculator

it's just our first try to create project for ios

hope you enjoy it :smile:

## ScreenShots

![Alt Text](https://github.com/SamadiPour/SimpleCalculator/blob/master/screenshot2.png)

![Alt Text](https://github.com/SamadiPour/SimpleCalculator/blob/master/screenshot3.png)
